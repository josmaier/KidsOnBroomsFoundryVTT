export const KIDSONBROOMS = {};

// Define constants here, such as:
KIDSONBROOMS.foobar = {
  'bas': 'KIDSONBROOMS.bas',
  'bar': 'KIDSONBROOMS.bar'
};